# -*- coding:utf8 -*-
from django.conf.urls import url
from home import views


urlpatterns = [
    url(r'^homeList/$', views.home_list),  # 首页分类列表
    url(r'^typeList/$', views.yh_type_list),  # 优惠类型列表
    url(r'^yhList/$', views.yh_list),  # 优惠列表
    url(r'^findList/$', views.find_list),  # 寻找列表
    url(r'^ershouList/$', views.ershou_list),  # 二手列表
    url(r'^useCarList/$', views.use_car_list),  # 用车列表

]
