from django.shortcuts import render
# Create your views here.
# -*- coding:utf8 -*-

from django.http import HttpResponse
import json
from . import models

# 转换成json形式
def toDict(objs):
    obj_arr = []
    for o in objs:
        obj_arr.append(o.toDict())
    return obj_arr


#  查询所有优惠分类
def yh_type_list(request):
     type_list = models.YouHuiType.objects.all()
     all_data = toDict(type_list)
     all_json = json.dumps(all_data, ensure_ascii=False)
     print (all_json)
     return HttpResponse(all_json)

#  查询所有优惠信息
def yh_list(request):
     yhxs_list = models.Youhui.objects.all()
     all_data = toDict(yhxs_list)
     all_json = json.dumps(all_data, ensure_ascii=False)
     print (all_json)
     return HttpResponse(all_json)



#  查询所有寻找信息
def find_list(request):
     fd_list = models.Finds.objects.all()
     all_data = toDict(fd_list)
     all_json = json.dumps(all_data, ensure_ascii=False)
     print (all_json)
     return HttpResponse(all_json)

#  查询所有优惠信息
def use_car_list(request):
     uc_list = models.UseCar.objects.all()
     all_data = toDict(uc_list)
     all_json = json.dumps(all_data, ensure_ascii=False)
     print (all_json)
     return HttpResponse(all_json)


#  查询所有优惠信息
def ershou_list(request):
     ershou_list = models.ErShouMessage.objects.all()
     all_data = toDict(ershou_list)
     all_json = json.dumps(all_data, ensure_ascii=False)
     print (all_json)
     return HttpResponse(all_json)




# 首页分类数据
def home_list(request):
    # project_list = models.Project.objects.filter(id__lte=3)
    # project_toDic = toDict(project_list)

    # problem_list = models.Problem.objects.filter(id__lt=2)
    yh_list = models.Youhui.objects.all()
    yh_toDic = toDict(yh_list) #优惠信息

    # news_list = models.News.objects.filter(id__lte=6)
    # news_toDic = toDicts(news_list)
    find_list = models.Finds.objects.all() # 寻找信息
    find_toDic = toDict(find_list)

    # point_list = models.KeyPoit.objects.filter(id__lt=2)
    usecar_list = models.UseCar.objects.all() #用车信息
    usecar_toDic = toDict(usecar_list)

    ershou_list = models.ErShouMessage.objects.all()
    ershou_toDic = toDict(ershou_list) #二手信息


    #
    text_context = {'yh_list': yh_toDic, 'find_list': find_toDic,
               'usecar_list': usecar_toDic, 'ershou_list': ershou_toDic,
               }

    # textTwoContent = {'newsList': news_toDic, 'messageList': message_toDic, }
    # print (text_context)
    # text_context = [news_toDic, message_toDic, problem_toDic, ]
    # # contxt_dic = {'content': text_context}
    all_json = json.dumps(text_context, ensure_ascii=False)
    print (all_json)
    return HttpResponse(all_json)

