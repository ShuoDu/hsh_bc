from django.contrib import admin
# -*- coding:utf8 -*-
from home.models import YouHuiType, ShowType, Youhui, FindType, Finds, UseCarType, UseCar, ErShouType, ErShouMessage

# class ConfigInline(admin.ModelAdmin):
#     model =  YouHuiType


class TyAdmin(admin.ModelAdmin):
    # inlines = [ConfigInline]

    search_fields = ('title',)
    list_display = ("__str__","content","send_user","time")

admin.site.site_header = '会生活APP后台管理系统'
admin.site.site_title = '会生活后台'
admin.site.site_app_label = '分类信息'
admin.site.register(YouHuiType)  # 优惠类型
admin.site.register(ShowType)  # 显示类型
admin.site.register(Youhui,TyAdmin)  # 优惠信息
admin.site.register(FindType) # 寻找类型
admin.site.register(Finds) # 寻找信息
admin.site.register(UseCarType) # 用车类型
admin.site.register(UseCar) # 用车信息
admin.site.register(ErShouMessage) # 二手类型
admin.site.register(ErShouType) # 二手信息