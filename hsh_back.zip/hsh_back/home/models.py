from __future__ import unicode_literals
from django.db import models
# -*- coding:utf8 -*-

# 优惠分类
class YouHuiType(models.Model):
    tname = models.CharField(max_length=50, verbose_name='优惠类型', blank=True)

    def __str__(self):
        return "%s" % self.tname  # 指定管理平台列名

    def toDict(self):
        return {'tname': self.tname, }

    class Meta:
        db_table = '优惠分类'
        verbose_name = '优惠分类'  # 单数时显示内容
        verbose_name_plural = '优惠分类'  # 复数时显示内容


# 显示类型
class ShowType(models.Model):
    tname = models.CharField(max_length=50,verbose_name='显示类型',blank=True) #是否推荐
    def __str__(self):
        return "%s" % self.tname  # 指定管理平台列名
    class Meta:
      db_table = '显示类型'
      verbose_name = '显示类型'  # 单数时显示内容
      verbose_name_plural = '显示类型'  # 复数时显示内容


#  优惠
class Youhui(models.Model):
    ytype = models.ForeignKey('YouHuiType',verbose_name="优惠类型",on_delete=models.CASCADE)
    showType = models.ForeignKey('ShowType', verbose_name="显示类型",on_delete=models.CASCADE)
    title = models.CharField(max_length=50, verbose_name='标题', blank=True)
    content = models.CharField(max_length=1000, verbose_name='内容', blank=True)
    contentUrl = models.CharField(max_length=100, verbose_name='内容地址', blank=True)
    time = models.CharField(max_length=100, verbose_name='发布时间', blank=True)
    news_img_one = models.ImageField(upload_to='img', verbose_name='新闻图片1')  # 新闻图片
    news_img_two = models.ImageField(upload_to='img', verbose_name='新闻图片2', blank=True)  # 新闻图片
    news_img_three = models.ImageField(upload_to='img', verbose_name='新闻图片3', blank=True)  # 新闻图片
    dianzan = models.IntegerField(default=0, verbose_name='点赞数', blank=True)
    pinglun_count = models.IntegerField(default=0, verbose_name="评论量", blank=True)
    yuedu_count = models.IntegerField(default=0, verbose_name="阅读量", blank=True)
    # user = models.ForeignKey('UserInfo',verbose_name="发布人",on_delete=models.CASCADE)
    user_logo = models.CharField(max_length=1000,verbose_name='用户头像', blank=True)
    send_user =  models.CharField(max_length=1000,verbose_name='发布人', blank=True)
    pice =  models.IntegerField(default=0, verbose_name='价格', blank=True)
    # yh = models.OneToOneField(YouHuiType,on_delete=models.CASCADE,null=True)

    def __str__(self):
        return "%s" % self.title  # 指定管理平台列名

    class Meta:
        db_table = 'youhui'
        verbose_name = '优惠信息'  # 单数时显示内容
        verbose_name_plural = '优惠信息'  # 复数时显示内容



    def toDict(self):
        return {'title': self.title, 'content': self.content,
                'contentUrl': self.contentUrl, 'time': self.time, 'dianzan': self.dianzan,
                'pinglun': self.pinglun_count, 'imgOneUrl': self.news_img_one.url,
                }

#  'imgTwoUrl': self.news_img_two.url, 'imgThreeUrl': self.news_img_three.url




# 寻找分类
class FindType(models.Model):
    f_name = models.CharField(max_length=50,verbose_name='寻找类型',blank=True) #寻人寻物
    def __str__(self):
        return "%s" % self.f_name  # 指定管理平台列名

    def toDict(self):
        return {'f_name': self.f_name, }

    class Meta:
        db_table = '寻找分类'
        verbose_name = '寻找分类'  # 单数时显示内容
        verbose_name_plural = '寻找分类'  # 复数时显示内容

# 寻人寻物
class Finds(models.Model):
    f_type = models.ForeignKey('FindType',verbose_name="寻找类型",on_delete=models.CASCADE) #人或者物品
    showType = models.ForeignKey('ShowType',verbose_name="显示类型",on_delete=models.CASCADE) #普通或者推荐
    title = models.CharField(max_length=50, verbose_name='标题', blank=True)
    content = models.CharField(max_length=10000, verbose_name='内容', blank=True)
    contentUrl = models.CharField(max_length=100, verbose_name='内容地址', blank=True)
    time = models.CharField(max_length=100, verbose_name='时间', blank=True)
    news_img_one = models.ImageField(upload_to='img', verbose_name='图片1')  # 新闻图片
    news_img_two = models.ImageField(upload_to='img', verbose_name='图片2', blank=True)  # 图片可不上传
    news_img_three = models.ImageField(upload_to='img', verbose_name='图片3', blank=True)
    dianzan = models.IntegerField(default=0, verbose_name='点赞数', blank=True)
    pinglun_count = models.IntegerField(default=0, verbose_name="评论量", blank=True)
    yuedu_count = models.IntegerField(default=0, verbose_name="阅读量", blank=True)
    # user = models.ForeignKey('UserInfo',verbose_name="发布人",on_delete=models.CASCADE)
    user_logo = models.CharField(max_length=1000,verbose_name='用户头像', blank=True)
    pice =  models.IntegerField(default=0, verbose_name='悬赏金额', blank=True)
    phonePeople = models.CharField(max_length=100, verbose_name='联系人', blank=True)
    tellphone = models.CharField(max_length=50, verbose_name='联系电话', blank=True)
    def __str__(self):
        return "%s" % self.title  # 指定管理平台列名

    class Meta:
        db_table = '悬赏寻物'
        verbose_name = '悬赏寻物'  # 单数时显示内容
        verbose_name_plural = '悬赏寻物'  # 复数时显示内容

    def toDict(self):
        return {'title': self.title, 'content': self.content,
                'contentUrl': self.contentUrl, 'time': self.time, 'dianzan': self.dianzan,
                'pinglun': self.pinglun_count, 'imgOneUrl': self.news_img_one.url,
                }

# 用车分类
class UseCarType(models.Model):
    use_car_name = models.CharField(max_length=50,verbose_name='用车类型',blank=True) #拼车，租车，车队
    def __str__(self):
        return "%s" % self.use_car_name  # 指定管理平台列名

    def toDict(self):
        return {'use_car_name': self.use_car_name, }

    class Meta:
        db_table = '用车分类'
        verbose_name = '用车分类'  # 单数时显示内容
        verbose_name_plural = '用车分类'  # 复数时显示内容


# 拼车租车车队
class UseCar(models.Model):
    use_type = models.ForeignKey('UseCarType',verbose_name="用车类型",on_delete=models.CASCADE) #拼车，租车，车队
    showType = models.ForeignKey('ShowType',verbose_name="显示类型",on_delete=models.CASCADE) #普通或者推荐
    title = models.CharField(max_length=50, verbose_name='标题', blank=True)
    content = models.CharField(max_length=10000, verbose_name='内容', blank=True)
    contentUrl = models.CharField(max_length=100, verbose_name='内容地址', blank=True)
    startTime = models.CharField(max_length=100, verbose_name='出发时间', blank=True)
    startAddress = models.CharField(max_length=100, verbose_name='出发地', blank=True)
    endAddress = models.CharField(max_length=100, verbose_name='目的地', blank=True)
    news_img_one = models.ImageField(upload_to='img', verbose_name='图片1')  # 新闻图片
    news_img_two = models.ImageField(upload_to='img', verbose_name='图片2', blank=True)  # 图片可不上传
    news_img_three = models.ImageField(upload_to='img', verbose_name='图片3', blank=True)
    dianzan = models.IntegerField(default=0, verbose_name='点赞数', blank=True)
    pinglun_count = models.IntegerField(default=0, verbose_name="评论量", blank=True)
    yuedu_count = models.IntegerField(default=0, verbose_name="阅读量", blank=True)
    phonePeople = models.CharField(max_length=100, verbose_name='联系人', blank=True)
    tellphone = models.CharField(max_length=50, verbose_name='联系电话', blank=True)
    # user = models.ForeignKey('UserInfo',verbose_name="发布人",on_delete=models.CASCADE)
    user_logo = models.CharField(max_length=1000,verbose_name='用户头像', blank=True)
    pice =  models.IntegerField(default=0, verbose_name='金额', blank=True)

    def __str__(self):
        return "%s" % self.title # 指定管理平台列名

    class Meta:
        db_table = '拼车用车'
        verbose_name = '拼车用车'  # 单数时显示内容
        verbose_name_plural = '拼车用车'  # 复数时显示内容

    def toDict(self):
        return {'title': self.title, 'content': self.content,
                'contentUrl': self.contentUrl, 'startAddress':self.startAddress, 'endAddress':self.endAddress, 'start_time': self.startTime, 'dianzan': self.dianzan,
                'pinglun': self.pinglun_count, 'imgOneUrl': self.news_img_one.url,
                }

# 二手分类
class ErShouType(models.Model):
    ershou_type = models.CharField(max_length=50,verbose_name='二手类型',blank=True) #家电手机家具其他
    def __str__(self):
        return "%s" % self.ershou_type  # 指定管理平台列名
    def toDict(self):
        return {'ershou_type': self.ershou_type }
    class Meta:
        db_table = '二手分类'
        verbose_name = '二手分类'  # 单数时显示内容
        verbose_name_plural = '二手分类'  # 复数时显示内容



# 二手信息
class ErShouMessage(models.Model):
    ershou_type = models.ForeignKey('ErShouType',verbose_name="二手类型",on_delete=models.CASCADE) #家具家电日用其他
    showType = models.ForeignKey('ShowType',verbose_name="显示类型",on_delete=models.CASCADE) #普通或者推荐
    title = models.CharField(max_length=50, verbose_name='标题', blank=True)
    content = models.CharField(max_length=10000, verbose_name='内容', blank=True)
    contentUrl = models.CharField(max_length=100, verbose_name='内容地址', blank=True)
    startTime = models.CharField(max_length=100, verbose_name='出发时间', blank=True)
    news_img_one = models.ImageField(upload_to='img', verbose_name='图片1')  # 新闻图片
    news_img_two = models.ImageField(upload_to='img', verbose_name='图片2', blank=True)  # 图片可不上传
    news_img_three = models.ImageField(upload_to='img', verbose_name='图片3', blank=True)
    dianzan = models.IntegerField(default=0, verbose_name='点赞数', blank=True)
    pinglun_count = models.IntegerField(default=0, verbose_name="评论量", blank=True)
    yuedu_count = models.IntegerField(default=0, verbose_name="阅读量", blank=True)
    phonePeople = models.CharField(max_length=100, verbose_name='联系人', blank=True)
    tellphone = models.CharField(max_length=50, verbose_name='联系电话', blank=True)
    user = models.CharField(max_length=100, verbose_name='用户名', blank=True)
    user_logo = models.CharField(max_length=1000,verbose_name='用户头像', blank=True)
    pice =  models.IntegerField(default=0, verbose_name='金额', blank=True)

    def __str__(self):
        return "%s" % self.title  # 指定管理平台列名

    class Meta:
        db_table = '二手信息'
        verbose_name = '二手信息'  # 单数时显示内容
        verbose_name_plural = '二手信息'  # 复数时显示内容

    def toDict(self):
        return {'title': self.title, 'content': self.content,
                'contentUrl': self.contentUrl,  'dianzan': self.dianzan,
                'pinglun': self.pinglun_count, 'imgOneUrl': self.news_img_one.url,'phonePeople':self.phonePeople,'tellphone':self.tellphone
                }


